package com.example.smartair.r3;

public class RescueLogEntry extends MedicineLogEntry {
    public RescueLogEntry(String name, int doseCount, String timestamp) {
        super(name, doseCount, timestamp);
    }
}
