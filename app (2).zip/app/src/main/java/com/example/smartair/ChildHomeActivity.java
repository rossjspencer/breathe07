package com.example.smartair;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.*;
import android.content.Intent;
import com.example.smartair.R4.pef.PefEntryActivity;
import com.example.smartair.R4.triage.TriageActivity;
import com.example.smartair.r3.BadgesActivity;
import com.example.smartair.r3.MedicineLogActivity;
import com.example.smartair.r3.MedicineLogFragment;
import com.example.smartair.r3.InhalerGuideActivity;
import com.example.smartair.r3.GuideStats;
import com.example.smartair.r3.RescueLogEntry;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.TimeUnit;

public class ChildHomeActivity extends AppCompatActivity {

    private TextView tvCurrentZone, tvZoneDescription;
    private DatabaseReference mDatabase;
    private String currentChildId;
    private String childName = "";
    private int personalBest = 400;
    
    private static final String BADGE_CHANNEL_ID = "badge_alerts";
    private static final String PREFS_BADGES = "badge_prefs";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_child_home);

        tvCurrentZone = findViewById(R.id.tvCurrentZone);
        tvZoneDescription = findViewById(R.id.tvZoneDescription);
        
        Button btnTakeDose = findViewById(R.id.btnTakeDose);
        Button btnLogPef = findViewById(R.id.btnLogPef);
        Button btnLogSymptoms = findViewById(R.id.btnLogSymptoms);
        Button btnViewRescueLog = findViewById(R.id.btnViewRescueLog);
        Button btnViewControllerLog = findViewById(R.id.btnViewControllerLog);
        Button btnViewHistory = findViewById(R.id.btnViewHistory);
        Button btnAwards = findViewById(R.id.btnAwards);

        // Triage button (keep)
        Button triageButton = findViewById(R.id.triage_button);
        triageButton.setOnClickListener(v -> {
            Intent i = new Intent(ChildHomeActivity.this, TriageActivity.class);
            i.putExtra("childId", currentChildId);
            startActivity(i);
        });

        mDatabase = FirebaseDatabase.getInstance().getReference();

        if (getIntent().hasExtra("CHILD_ID")) {
            currentChildId = getIntent().getStringExtra("CHILD_ID");
        } else if (FirebaseAuth.getInstance().getCurrentUser() != null) {
            currentChildId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        }

        if (currentChildId != null) {
            loadChildData();
            checkWellControlledBadge();
        } else {
            Toast.makeText(this, "Error: Not Logged In", Toast.LENGTH_SHORT).show();
            finish();
        }
        
        // Wire up Take Dose button
        btnTakeDose.setOnClickListener(v -> {
            Intent intent = new Intent(ChildHomeActivity.this, InhalerGuideActivity.class);
            intent.putExtra("CHILD_ID", currentChildId);
            startActivity(intent);
        });

        // Launch R4 PEF screen instead of dialog
        btnLogPef.setOnClickListener(v -> {
            Intent i = new Intent(ChildHomeActivity.this, PefEntryActivity.class);
            i.putExtra("childId", currentChildId);
            startActivity(i);
        });

        // Wire up log symptoms button
        btnLogSymptoms.setOnClickListener(v -> {
            Intent intent = new Intent(ChildHomeActivity.this, DailyLogActivity.class);
            intent.putExtra("CHILD_ID", currentChildId);
            intent.putExtra("LOGGED_BY_ROLE", "Child");
            intent.putExtra("CHILD_NAME", childName);
            startActivity(intent);
        });
        
        btnViewRescueLog.setOnClickListener(v -> {
            Intent intent = new Intent(ChildHomeActivity.this, MedicineLogActivity.class);
            intent.putExtra("CHILD_ID", currentChildId);
            intent.putExtra(MedicineLogFragment.ARG_TYPE, "RESCUE");
            startActivity(intent);
        });
        
        btnViewControllerLog.setOnClickListener(v -> {
            Intent intent = new Intent(ChildHomeActivity.this, MedicineLogActivity.class);
            intent.putExtra("CHILD_ID", currentChildId);
            intent.putExtra(MedicineLogFragment.ARG_TYPE, "CONTROLLER");
            startActivity(intent);
        });

        // Wire up history button
        btnViewHistory.setOnClickListener(v -> {
            Intent intent = new Intent(ChildHomeActivity.this, HistoryActivity.class);
            intent.putExtra("CHILD_ID", currentChildId);
            intent.putExtra("CHILD_NAME", childName);
            startActivity(intent);
        });
        
        // Wire up awards button
        btnAwards.setOnClickListener(v -> {
            Intent intent = new Intent(ChildHomeActivity.this, BadgesActivity.class);
            intent.putExtra("CHILD_ID", currentChildId);
            startActivity(intent);
        });
    }

    private void loadChildData() {
        mDatabase.child("users").child(currentChildId).addValueEventListener(new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    if (snapshot.hasChild("firstName")) {
                        childName = snapshot.child("firstName").getValue(String.class);
                    }
                    Integer pb = snapshot.child("personalBest").getValue(Integer.class);
                    if (pb != null && pb > 0) personalBest = pb;

                    Integer score = snapshot.child("asthmaScore").getValue(Integer.class);
                    updateZoneUI(score != null ? score : 100);
                }
            }
            @Override public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

    private void updateZoneUI(int score) {
        tvCurrentZone.setText(score + "%");
        if (score >= 80) {
            tvCurrentZone.setTextColor(Color.parseColor("#4CAF50"));
            tvZoneDescription.setText("Green Zone (All Good)");
            tvZoneDescription.setTextColor(Color.parseColor("#4CAF50"));
        } else if (score >= 50) {
            tvCurrentZone.setTextColor(Color.parseColor("#FFC107"));
            tvZoneDescription.setText("Yellow Zone (Caution)");
            tvZoneDescription.setTextColor(Color.parseColor("#FFC107"));
        } else {
            tvCurrentZone.setTextColor(Color.parseColor("#F44336"));
            tvZoneDescription.setText("Red Zone (Danger)");
            tvZoneDescription.setTextColor(Color.parseColor("#F44336"));
        }
    }
    
    private void checkWellControlledBadge() {
        DatabaseReference statsRef = FirebaseDatabase.getInstance().getReference("guide_stats").child(currentChildId);
        // Using medicine_logs/rescue
        DatabaseReference logsRef = FirebaseDatabase.getInstance("https://smartair-a6669-default-rtdb.firebaseio.com")
                .getReference("medicine_logs").child("rescue").child(currentChildId);
        DatabaseReference settingsRef = FirebaseDatabase.getInstance().getReference("badge_settings").child(currentChildId);
        
        settingsRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                int badge3Threshold = 4; // Default
                Integer b3 = snapshot.child("badge3_threshold").getValue(Integer.class);
                if (b3 != null) badge3Threshold = b3;
                
                int finalThreshold = badge3Threshold;
                logsRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot logsSnap) {
                        Set<String> uniqueDays = new HashSet<>();
                        Calendar cal = Calendar.getInstance();
                        cal.add(Calendar.DAY_OF_YEAR, -30);
                        Date thirtyDaysAgo = cal.getTime();
                        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault());
                        SimpleDateFormat daySdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());

                        for (DataSnapshot child : logsSnap.getChildren()) {
                            RescueLogEntry entry = child.getValue(RescueLogEntry.class);
                            if (entry != null && entry.timestamp != null) {
                                try {
                                    Date entryDate = sdf.parse(entry.timestamp);
                                    if (entryDate != null && entryDate.after(thirtyDaysAgo)) {
                                        uniqueDays.add(daySdf.format(entryDate));
                                    }
                                } catch (ParseException e) { }
                            }
                        }
                        
                        if (uniqueDays.size() <= finalThreshold) {
                            statsRef.addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot statsSnapshot) {
                                    GuideStats stats = statsSnapshot.getValue(GuideStats.class);
                                    if (stats == null) stats = new GuideStats(0, 0, "", "");
                                    
                                    boolean accountOldEnough = false;
                                    if (stats.accountCreationDate != null && !stats.accountCreationDate.isEmpty()) {
                                        try {
                                            SimpleDateFormat dateSdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
                                            Date creationDate = dateSdf.parse(stats.accountCreationDate);
                                            if (creationDate != null) {
                                                long diff = new Date().getTime() - creationDate.getTime();
                                                long daysSince = TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
                                                if (daysSince >= 30) {
                                                    accountOldEnough = true;
                                                }
                                            }
                                        } catch (ParseException e) { }
                                    }
                                    
                                    if (accountOldEnough) {
                                        if (!stats.hasBadge("badge_well_controlled")) {
                                            // Check if already notified locally
                                            SharedPreferences prefs = getSharedPreferences(PREFS_BADGES, MODE_PRIVATE);
                                            boolean notified = prefs.getBoolean("notified_badge_well_controlled", false);
                                            
                                            if (!notified) {
                                                sendBadgeNotification("Well Controlled");
                                                prefs.edit().putBoolean("notified_badge_well_controlled", true).apply();
                                            }
                                        }
                                    }
                                }
                                @Override public void onCancelled(@NonNull DatabaseError e) {}
                            });
                        }
                    }
                    @Override public void onCancelled(@NonNull DatabaseError e) {}
                });
            }
            @Override public void onCancelled(@NonNull DatabaseError e) {}
        });
    }
    
    private void sendBadgeNotification(String badgeName) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Badge Alerts";
            String description = "Notifications for earned badges";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(BADGE_CHANNEL_ID, name, importance);
            channel.setDescription(description);
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
        
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, BADGE_CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher_round)
                .setContentTitle("Badge Unlocked!")
                .setContentText("You earned the " + badgeName + " badge! Come claim it in Awards.")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true);

        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
        try {
            notificationManager.notify(badgeName.hashCode(), builder.build());
        } catch (SecurityException e) {
            // ignore
        }
    }
}