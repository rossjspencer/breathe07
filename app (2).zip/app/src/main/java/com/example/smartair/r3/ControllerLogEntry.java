package com.example.smartair.r3;

public class ControllerLogEntry extends MedicineLogEntry {

    public ControllerLogEntry(){
        super();
    }

    public ControllerLogEntry(String name, int doseCount, String timestamp){
        super(name, doseCount, timestamp);
    }
}
