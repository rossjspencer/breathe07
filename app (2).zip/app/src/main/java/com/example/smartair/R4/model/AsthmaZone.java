package com.example.smartair.R4.model;

public enum AsthmaZone {
    GREEN,
    YELLOW,
    RED,
    UNKNOWN
}