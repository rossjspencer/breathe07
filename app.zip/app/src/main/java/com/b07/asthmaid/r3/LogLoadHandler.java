package com.b07.asthmaid.r3;

import java.util.ArrayList;

public class LogLoadHandler {
    ArrayList<ControllerLogEntry> controllerLogs;
    ArrayList<RescueLogEntry> rescueLogs;

    public void loadLog(){
        //load log from firebase
    }

    public void saveLog(){
        //save log to firebase
    }
}
